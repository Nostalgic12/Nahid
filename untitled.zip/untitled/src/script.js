document.addEventListener('DOMContentLoaded', function () {

    // Neural Network Animation

    function createNeuralNetwork() {

        const container = document.getElementById('networkCanvas');

        const neuronCount = 50;

        for (let i = 0; i < neuronCount; i++) {

            const neuron = document.createElement('div');

            neuron.className = 'neuron';

            neuron.style.left = `${Math.random() * 100}%`;

            neuron.style.top = `${Math.random() * 100}%`;

            neuron.style.animationDelay = `${Math.random() * 2}s`;

            container.appendChild(neuron);

        }

    }

    createNeuralNetwork();

    // Show Features Button

    const showFeaturesBtn = document.getElementById('show-features-btn');

    const features = document.getElementById('features');

    showFeaturesBtn.addEventListener('click', function () {

        features.classList.toggle('hidden');

    });

    // Theme Toggle

    const themeToggle = document.getElementById('theme-toggle');

    const body = document.body;

    themeToggle.addEventListener('click', () => {

        body.classList.toggle('dark-theme');

        if (body.classList.contains('dark-theme')) {

            themeToggle.textContent = '☀️'; // Sun icon for light mode

        } else {

            themeToggle.textContent = '🌙'; // Moon icon for dark mode

        }

    });

    // Reveal Hidden Content

    document.getElementById('reveal-btn')?.addEventListener('click', function () {

        let hiddenContent = document.getElementById('hidden-content');

        hiddenContent.style.display = 'block';

        hiddenContent.classList.add('animated');

    });

    // Scroll Animation

    const sections = document.querySelectorAll('.animated-section');

    const checkVisibility = () => {

        sections.forEach(section => {

            const sectionTop = section.getBoundingClientRect().top;

            const sectionBottom = section.getBoundingClientRect().bottom;

            if (sectionTop < window.innerHeight && sectionBottom > 0) {

                section.classList.add('visible');

            } else {

                section.classList.remove('visible');

            }

        });

    };

    window.addEventListener('scroll', checkVisibility);

    checkVisibility();

    // Sign-Up Form

    const signupBtn = document.getElementById('signup-btn');

    const signupForm = document.getElementById('signup-form');

    const signupFormElement = document.getElementById('signupForm');

    signupBtn?.addEventListener('click', (e) => {

        e.stopPropagation();

        signupForm.style.display = 'block';

    });

    window.addEventListener('click', () => {

        signupForm.style.display = 'none';

    });

    signupForm.addEventListener('click', (e) => {

        e.stopPropagation();

    });

    signupFormElement.addEventListener('submit', (e) => {

        e.preventDefault();

        const username = document.getElementById('username').value.trim();

        const email = document.getElementById('email').value.trim();

        const password = document.getElementById('password').value.trim();

        // Validation

        if (username.length < 3) {

            alert('Username must be at least 3 characters long.');

            return;

        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {

            alert('Please enter a valid email address.');

            return;

        }

        if (password.length < 6) {

            alert('Password must be at least 6 characters long.');

            return;

        }

        alert(`Signup Successful!\nUsername: ${username}\nEmail: ${email}`);

        signupForm.style.display = 'none';

        signupFormElement.reset();

    });

});